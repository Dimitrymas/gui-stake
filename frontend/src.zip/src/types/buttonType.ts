export enum ButtonType {
    Primary,
    Secondary,
}