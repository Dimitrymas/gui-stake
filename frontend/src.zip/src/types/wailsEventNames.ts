export namespace telegramEvents {
    export const QrRecreateEvent: string = "telegram:QrRecreate";
    export const Qr2FARequiredEvent: string = "telegram:Qr2FARequired";
    export const QrErrorEvent: string = "telegram:QrError";
    export const QrLoggedInEvent: string = "telegram:QrLoggedIn";
}