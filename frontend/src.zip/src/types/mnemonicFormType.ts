export enum MnemonicFormType {
    Login,
    Register,
}