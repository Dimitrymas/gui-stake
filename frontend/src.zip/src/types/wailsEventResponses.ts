export namespace telegramResponses {
    export type QrRecreateResponse = {
        error: string;
        qr_url: string;
    }
}