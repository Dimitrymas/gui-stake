export enum RegisterStep {
    ReadMnemonic,
    WriteMnemonic
}
