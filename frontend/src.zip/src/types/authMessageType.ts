export enum AuthMessageType {
    Login,
    Register,
}
