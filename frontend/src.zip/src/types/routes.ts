export enum Routes {
    LoginPage = "/login",
    RegisterPage = "/register",
    HomePage = "/",
    ProfilePage = "/profile",
    SettingsPage = "/settings",
}